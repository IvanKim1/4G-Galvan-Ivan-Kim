<!DOCTYPE html>
<html>

<!–– css link ––>
      <link rel="stylesheet" type="text/css" href="assets\css\style.css">

  <meta charset="UTF-8">
 
<title>
    Contact
</title>
 <header>
  <center>
    <div class= "title">
      <h1>  Ivan's Biography </h1> 
        </div>    
          <div class="line1"> 
           <div class="Navbar">          
  </div>   
                     