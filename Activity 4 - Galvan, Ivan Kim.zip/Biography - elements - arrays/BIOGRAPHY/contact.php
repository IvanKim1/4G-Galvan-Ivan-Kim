<?php
 include 'header.php';
?>
      
</head>
   <body>
      <center>
        </div>       
         <body>             
           </ul>    
                 
          <li><p> Ivan Kim Galvan </p> </li>
         <li><p>galvanivankim@gmail.com</p></li>
         <li><p>Contact: 09670114141</p></li>

          </ul>
                        
                </div>    
                                                

                </div>                  
                
</html>