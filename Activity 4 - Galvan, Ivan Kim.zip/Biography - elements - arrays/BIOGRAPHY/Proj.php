<?php
 include 'header.php';

?>


 <title>Ivan's autobiography</title> 

<!–– css link ––>
      <link rel="stylesheet" type="text/css" href="assets\css\style.css">
      
</head>
        <body>
            <center>

  <a href="#"><img src="assets\images\NXTLVL_GALVAN_KIM_Banner.png"></a>
  </div>       
    <body>             
     </div> 
      
              
        <div class="PERSONAL INFORMATION"> 
<span> PERSONAL INFORMATION 

      
     <div class="Name">  <span> Name: </span> <?php include 'index.php'; echo $info['Name']; ?></div>
     <div class="Name">  <span> Age:
</span> <?php include 'index.php'; echo $info['Age']; ?></div>
     <div class="Name">  <span> Sex: </span>
 <?php include 'index.php'; echo $info['Sex']; ?></div>
     <div class="Name">  <span> Date of Birth: </span> 
<?php include 'index.php'; echo 

$info['Date of Birth']; ?></div>
     <div class="Name">  <span> Nationality: </span> 
<?php include 'index.php'; echo $info['Nationality']; ?></div>
     
<div class = "name"> <span> Religion: </ span>
<?php  include 'index.php'; echo

$info['Religion']; ?>
</div>
     <br>
       <div class="text"> <p>
       <body>My name is Ivan Kim Galvan and I was born on the 15th of March,2001 in Sapa - sapa Ibabao Mandaue City. 
	       My parents names are Isaganie and Analyn. I have 1 sister,we are 2 in total.
	       
	      <p></p> There are a lot of things I like and i dont. I like to have fun with my friends, I love watching movies, and listening to spotify,
	       but what I really love is to playing computer games. I play computer games when I have free time.
	       It also gives me happiness and peace.
</body> 
</html>