
        <!–– Footer ––>
          <footer id="footer">
            <div class="container">
              <div class="footer-col">
                <h4>SUSPENDISSE</h4>
                  <ul>
                    <li><a href="#">Quisque</a></li>
                    <li><a href="#">Faucibus</a></li>
                    <li><a href="#">Sapien</a></li>
                     <li><a href="#">Hendrerit</a></li>
                  </ul>
              </div>
          <div class="footer-col">
              <h4>PORTA</h4>
                <ul>
                  <li><a href="#">Mauris</a></li>
                  <li><a href="#">Suscipit</a></li>
                  <li><a href="#">At ipsum</a></li>
                  <li><a href="#">Vehicula</a></li>
                </ul>
            </div>
            <div class="footer-col">
              <h4>FEUGIAT</h4>
                <ul>
                  <li><a href="#">Pellentesque</a></li>
                  <li><a href="#">Accumsan</a></li>
                  <li><a href="#">Velit in urna</a></li>
                   <li><a href="#">Faucibus</a></li>
                </ul>
            </div>
            <div class="footer-col">
              <h4>PLACERAT</h4>
                <ul>
                  <li><a href="#">Vitae</a></li>
                  <li><a href="#">Convallis</a></li>
                  <li><a href="#">Augue</a></li>
                   <li><a href="#">Aliquam</a></li>
                </ul>
            </div>
          </footer>
      </body>
</html>