<!DOCTYPE html>
  <html> 
    <head>
      <!–– meta tag ––>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title> 7/11 </title>

      <!–– css link ––>
      <link rel="stylesheet" type="text/css" href="assets\css\style.css">
    </head>

      <body>
        <header>
      <!–– 7/11 logo ––>
          <div id="logo">
            <a href="#"><img src="assets\images\NXTLVL_WEBDEB_711_Banner.png"></a>
          </div>
      <!–– Navigation Menu ––>
            <nav id="top-nav"> 
              <ul id="top-ul">
                <li><a href="#" >Praesentium</a></li>
                <li><a href="#" >Voluptatum</a></li>
                <li><a href="#" >Dignissimos</a></li>
                <li><a href="#" >Blanditiis</a></li>
                </ul>  
              </nav>
        </header>

      <!–– Main Form––>