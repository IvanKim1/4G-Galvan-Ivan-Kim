<?php 

$info = array ("Name" => "Ivan Kim Galvan", "Age" => "21" ,  "Sex" => "Male" , "Date of Birth" => "March 15, 2001", "Nationality" => "Filipino", "Religion" => "Catholic");

?>