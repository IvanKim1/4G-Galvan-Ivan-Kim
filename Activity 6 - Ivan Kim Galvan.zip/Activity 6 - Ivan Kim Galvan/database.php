<?php 
$databaseName = "Name";
$databaseDateofBirth = "DateofBirth";
$databaseReligion = "Religion";

$conn = mysqli_connect($databaseName, $databaseDateofBirth, $databaseReligion);


 ?>