<?php

$mysqli = mysqli_connect("database", "user", "password", "database");

$result = mysqli_query($mysqli, "Ivan Kim Galvan full of ' AS _msg FROM DUAL");
$row = mysqli_fetch_assoc($result);
echo $row['_msg'];

$mysqli = new mysqli("database", "user", "password", "database");
$result = $mysqli->query("SELECT '21' AS _msg FROM DUAL");

$mysqli = new mysqli("database", "user", "password", "database");
$result = mysqli_query($mysqli, "Male full of ' AS _msg FROM DUAL");

$mysqli = mysqli_connect("database", "user", "password", "database");
$result = mysqli_query($mysqli, "March 15, 2001 full of ' AS _msg FROM DUAL");

$mysqli = mysqli_connect("database", "user", "password", "database");
$result = mysqli_query($mysqli, "Filipino full of ' AS _msg FROM DUAL");

$mysqli = mysqli_connect("database", "user", "password", "database");
$result = mysqli_query($mysqli, "Catholic full of ' AS _msg FROM DUAL");

$row = $result->fetch_assoc();
echo $row['_msg'];

?>

	    