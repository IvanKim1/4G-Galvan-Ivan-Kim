<?php 
include_once 'biography.php';

?>

<!DOCTYPE html>
<html>
<head>

<title></title>
</head>
<body>
<?php 
$sql = "SELECT * FROM biography;";
$result = mysqli_query($conn, $sql);
$resultant = mysqli_num_rows($result);
if($resultant > 0){
while ($row = mysqli_fetch_assoc ($result)){
echo $row['Religion']. "<br>";
   }
}

?>
<body>
</html>